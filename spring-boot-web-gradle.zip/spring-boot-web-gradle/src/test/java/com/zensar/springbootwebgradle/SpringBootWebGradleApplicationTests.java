package com.zensar.springbootwebgradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
